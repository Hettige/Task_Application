<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Daily Task App</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>  
    <div class="container">
        <div class="text-center">
            <h1 class="display-4">Daily Tasks</h1>
            <hr>
            <div class="row">
                <div class="col-md-12">

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($error); ?>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <form name="f1" method="POST" action="/saveTask">
                    <?php echo e(csrf_field()); ?>

                        <input type ="text" class="form-control" name="task" placeholder="Enter your Task..."/><br>
                        <input type="submit" class="btn btn-primary" value="Save Task"/>
                        <input type="reset" class="btn btn-warning" value="Clear All"/>
                    </form>

                    <hr>

                    <table class="table table-striped table-hover table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>Tasks</th>
                                <th>Completed</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>    
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($task->id); ?></td>
                                <td align="left"><?php echo e($task->task); ?></td>
                                <td>
                                    <?php if($task->iscompleted): ?>
                                        <button class="btn btn-success">Completed</button>
                                    <?php else: ?>
                                        <button class="btn btn-warning">Not Completed</button>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(!$task->iscompleted): ?>
                                        <a href="/markascompleted/<?php echo e($task->id); ?>" class="btn btn-primary">Mark as Completed</a>
                                    <?php else: ?>
                                        <a href="/markasnotcompleted/<?php echo e($task->id); ?>" class="btn btn-danger">Mark as Not Completed</a>
                                    <?php endif; ?>
                                    <a href="/deletetask/<?php echo e($task->id); ?>" class="btn btn-warning">Delete</a>
                                    <a href="/updatetask/<?php echo e($task->id); ?>" class="btn btn-success">Update</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>Tasks</th>
                                <th>Completed</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <hr>
            <center>
                <a class="btn btn-primary btn-sm" href="https://www.linkedin.com/in/mithun-hettige-b7130b69/" role="button">Created by M.H. Hettige</a>
                <a class="btn btn-danger btn-sm" href="/" role="button">Home</a>
            </center><br>
        </div>
    </div>
</body>
</html>