<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update Task</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="text-center">
            <hr>
            <div class="row">
                <div class="col-md-12">
                <h3>Update your Task</h3>
                    <form action="/updatetasks" method="POST" name="f2">
                    <?php echo e(csrf_field()); ?>

                        <input type="text" class="form-control" name="task" value="<?php echo e($taskdata->task); ?>"/>
                        <input type="hidden" name="id" value="<?php echo e($taskdata->id); ?>"/><br>
                        <input type="submit" class="btn btn-warning" value="Update"/>
                        <a href="/tasks" class="btn btn-danger">Cancel</a>
                    </form>
                    <hr>
                    <center><a class="btn btn-primary btn-sm" href="https://www.linkedin.com/in/mithun-hettige-b7130b69/" role="button">Created by M.H. Hettige</a></center><br>
                </div>
            </div>
        </div>
    </div>
</body>
</html>