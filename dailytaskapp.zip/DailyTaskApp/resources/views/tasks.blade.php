<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Daily Task App</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>  
    <div class="container">
        <div class="text-center">
            <h1 class="display-4">Daily Tasks</h1>
            <hr>
            <div class="row">
                <div class="col-md-12">

                    @foreach($errors->all() as $error)
                    <div class="alert alert-danger" role="alert">
                        {{$error}}
                    </div>
                    @endforeach
                    
                    <form name="f1" method="POST" action="/saveTask">
                    {{csrf_field()}}
                        <input type ="text" class="form-control" name="task" placeholder="Enter your Task..."/><br>
                        <input type="submit" class="btn btn-primary" value="Save Task"/>
                        <input type="reset" class="btn btn-warning" value="Clear All"/>
                    </form>

                    <hr>

                    <table class="table table-striped table-hover table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>Tasks</th>
                                <th>Completed</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>    
                            @foreach($tasks as $task)
                            <tr>
                                <td>{{$task->id}}</td>
                                <td align="left">{{$task->task}}</td>
                                <td>
                                    @if($task->iscompleted)
                                        <button class="btn btn-success">Completed</button>
                                    @else
                                        <button class="btn btn-warning">Not Completed</button>
                                    @endif
                                </td>
                                <td>
                                    @if(!$task->iscompleted)
                                        <a href="/markascompleted/{{$task->id}}" class="btn btn-primary">Mark as Completed</a>
                                    @else
                                        <a href="/markasnotcompleted/{{$task->id}}" class="btn btn-danger">Mark as Not Completed</a>
                                    @endif
                                    <a href="/deletetask/{{$task->id}}" class="btn btn-warning">Delete</a>
                                    <a href="/updatetask/{{$task->id}}" class="btn btn-success">Update</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                        <tfoot class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>Tasks</th>
                                <th>Completed</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <hr>
            <center>
                <a class="btn btn-primary btn-sm" href="https://www.linkedin.com/in/mithun-hettige-b7130b69/" role="button">Created by M.H. Hettige</a>
                <a class="btn btn-danger btn-sm" href="/" role="button">Home</a>
            </center><br>
        </div>
    </div>
</body>
</html>